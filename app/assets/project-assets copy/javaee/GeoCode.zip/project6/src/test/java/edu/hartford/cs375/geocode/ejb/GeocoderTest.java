package edu.hartford.cs375.geocode.ejb;

import static org.junit.Assert.assertEquals;

import java.util.logging.Logger;

import org.junit.Test;


public class GeocoderTest {

	private final static Logger logger = Logger.getLogger(GeocoderTest.class
			.getSimpleName());
	@Test
	public void testGetGeoCoordinates(){
		Geocoder geocoder = new Geocoder();
		GeoCoordinates gc = geocoder.getGeoCoordinates("200 Bloomfield Ave", "West Hartford", "CT", "06117");
		
		logger.info("lat: " + gc.getLatitude());
		logger.info("lng: " + gc.getLongitude());
		
		assertEquals(41.7948469,gc.getLatitude(),.00001);
		assertEquals(-72.71603229,gc.getLongitude(),.00001);
		
	}
	
}
