package edu.hartford.cs375.geocode.ejb;

import static org.junit.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.hartford.cs375.geocode.web.GeoCodeWebService;
import edu.hartford.cs375.geocode.ejb.Geocoder;

public class GeocodeWebServiceIT {

	private static GeoCodeWebService geocode;

	@BeforeClass
	public static void setupClass() throws MalformedURLException {
		URL wsdlURL = new URL("http://localhost:8080/geocode/GeocCdeService?wsdl");
		QName serviceName = new QName("http://cs375.hartford.edu/geocode/1.0.1");
		Service service = Service.create(wsdlURL, serviceName);
		geocode = service.getPort(GeoCodeWebService.class);
	}

	@Test
	public void tesetGeoCode() throws MalformedURLException {

		// Still need to make this test my geocode.getCoordinates() method
		
		// Geocoder geocode = geocode.getGeoCoordinates('200 Bloomfield Ave',
		// 'West Hartford', 'CT', '06117');

	}

}
