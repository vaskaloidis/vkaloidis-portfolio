package edu.hartford.cs375.geocode.ejb;

import java.io.IOException;
import java.io.StringReader;
import java.util.logging.Logger;

import javax.ejb.Stateless;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

/**
 * This EJB provides a SOAP Web Service wrapper around 
 * the Google Geocoding REST API.  The EJB exposes a single
 * public method, getGeoCoordinates, which returns the 
 * latitude and longitude for the provided address.
 * <em>NOTE: There are limits on the usage of this free
 * service.  You can obtain a key to use this service for
 * business-related work and have higher usage limits.</em>
 * 
 * @link https://developers.google.com/maps/documentation/geocoding
 */
@Stateless
public class Geocoder {

	private final static Logger logger = Logger.getLogger(Geocoder.class
			.getSimpleName());

	/**
	 * Uses the Apache HttpComponents HttlClient class to call the
	 * Google Geocoding service's REST API to resolve a street address
	 * to a latitude and longitude.
	 * @param street e.g., 200 Bloomfield Ave.
	 * @param city e.g., West Hartford
	 * @param state e.g., CT
	 * @param zip e.g., 06117
	 * @return GeoCoordinates object with longitude and latitude
	 */
	public GeoCoordinates getGeoCoordinates(String street, String city,
			String state, String zip) {

		//use auto-closable HttpClient
		try (CloseableHttpClient httpclient = HttpClients.createDefault()) {

			//instantiate a GET request with the appropriate URL
			//see the getUrl method for details on constructing the URL
			HttpGet httpget = new HttpGet(getUrl(street, city, state, zip));

			logger.info("executing request " + httpget.getURI());

			// Create a custom response handler
			ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

				public String handleResponse(final HttpResponse response)
					throws ClientProtocolException, IOException {
						int status = response.getStatusLine().getStatusCode();
	
						//make sure that the request was successful
						if (status >= 200 && status < 300) {
							//return the response body (entity)
							HttpEntity entity = response.getEntity();
							return entity != null ? EntityUtils.toString(entity)
									: null;
					} else {
						throw new ClientProtocolException(
								"Unexpected response status: " + status);
					}
				}

			};
			//execute the HTTP GET request and return the response body as a string
			String responseBody = httpclient.execute(httpget, responseHandler);
			
			//parse the JSON response into a GeoCoordinates object
			return parseJsonIntoGeoCoordinates(responseBody);

		} catch (IOException e) {
			return new GeoCoordinates(0, 0);
		}
	}

	
	private String getUrl(String street, String city, String state, String zip) {
		StringBuffer sb = new StringBuffer();
		sb.append("http://maps.googleapis.com/maps/api/geocode/json?address=");
		sb.append(street.replace(' ', '+'));
		sb.append(",+");
		sb.append(city.replace(' ', '+'));
		sb.append(",+");
		sb.append(state.replace(' ', '+'));
		sb.append("+");
		sb.append(zip);
		sb.append("&sensor=false");
		return sb.toString();
	}

	/**
	 * Parses the Google Geocoding REST JSON response, filtering out
	 * everything but the latitude and longitude, which are returned
	 * as a GeoCoordinates object.
	 * @param json The Google Geocoding REST JSON response
	 * @return GeoCoordinates object, holding the latitude and longitude
	 */
	private GeoCoordinates parseJsonIntoGeoCoordinates(String json) {

		GeoCoordinates gc = new GeoCoordinates();
		boolean latSet = false;
		boolean lngSet = false;

		JsonParser jsonParser = Json.createParser(new StringReader(json));
		Event event = null;

		// Advance to "geometry" key
		while (jsonParser.hasNext()) {
			event = jsonParser.next();
			if (event == Event.KEY_NAME && "geometry".equals(jsonParser.getString())) {
				event = jsonParser.next();
				break;
			}
		}
		// Advance to "location" key
		while (jsonParser.hasNext()) {
			event = jsonParser.next();
			if (event == Event.KEY_NAME && "location".equals(jsonParser.getString())) {
				event = jsonParser.next();
				break;
			}
		}
		// Get values for "lat" and "lng"
		while (jsonParser.hasNext()) {
			event = jsonParser.next();
			if (event == Event.KEY_NAME && "lat".equals(jsonParser.getString())) {
				event = jsonParser.next();
				//get latitude value
				gc.setLatitude(jsonParser.getBigDecimal().doubleValue());
				latSet = true;
			}
			if (event == Event.KEY_NAME && "lng".equals(jsonParser.getString())) {
				event = jsonParser.next();
				//get longitude value
				gc.setLongitude(jsonParser.getBigDecimal().doubleValue());
				lngSet = true;
			}
			if (latSet && lngSet)
				break;
		}

		return gc;
	}
}
