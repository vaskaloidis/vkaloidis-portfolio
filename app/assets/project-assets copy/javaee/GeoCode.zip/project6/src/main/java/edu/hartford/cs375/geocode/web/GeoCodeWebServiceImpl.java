package edu.hartford.cs375.geocode.web;

import javax.ejb.EJB; 
import javax.jws.WebService; 

import edu.hartford.cs375.geocode.ejb.GeoCoordinates;
import edu.hartford.cs375.geocode.ejb.Geocoder; 

@WebService(
		name="GeoCodeService",
		serviceName="GeoCodeService",
		targetNamespace="http://cs375.hartford.edu/geocode/1.0.1",
		endpointInterface="edu.hartford.cs375.geocode.web.GeoCodeWebService") 
public class GeoCodeWebServiceImpl 
		implements GeoCodeWebService {
	
	@EJB
	private Geocoder geocoder;
	
	public GeoCoordinates getGeoCoordinates(
			String street, String city,
			String state, String zip) {
		
		return geocoder.getGeoCoordinates(street, city, state, zip);
	}


}
