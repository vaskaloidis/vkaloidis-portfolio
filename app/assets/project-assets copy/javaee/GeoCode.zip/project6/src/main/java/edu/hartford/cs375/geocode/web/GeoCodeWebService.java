package edu.hartford.cs375.geocode.web;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService; 

import edu.hartford.cs375.geocode.ejb.GeoCoordinates;
//import edu.hartford.cs375.geocode.ejb.Geocoder; 
 
@WebService
public interface GeoCodeWebService {

	//GeoCoordinates getGeoCoordinates(String street, String city,String state, String zip)
	@WebResult(targetNamespace="http://cs375.hartford.edu/geocode/1.0.1")
	public GeoCoordinates getGeoCoordinates (
			
		@WebParam(name="street",
		targetNamespace="http://cs375.hartford.edu/geocode/1.0.1")
			String street,
		@WebParam(name="city",
		targetNamespace="http://cs375.hartford.edu/geocode/1.0.1")
			String city,
		@WebParam(name="state",
			targetNamespace="http://cs375.hartford.edu/geocode/1.0.1")
				String state,
			@WebParam(name="zip",
			targetNamespace="http://cs375.hartford.edu/geocode/1.0.1")
				String zip
		);

}
