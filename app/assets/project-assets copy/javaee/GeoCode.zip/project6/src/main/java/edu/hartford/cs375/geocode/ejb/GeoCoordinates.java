package edu.hartford.cs375.geocode.ejb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * This model class is a simple container for latitude and longitude.
 *
 */
@XmlType(namespace="http://cs375.hartford.edu/geocode/1.0.1", propOrder={})
@XmlAccessorType(XmlAccessType.FIELD)
public class GeoCoordinates implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private double latitude;
	private double longitude;
	
	public GeoCoordinates() {
		super();
	}
	
	public GeoCoordinates(double latitude, double longitude) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	
	
}
