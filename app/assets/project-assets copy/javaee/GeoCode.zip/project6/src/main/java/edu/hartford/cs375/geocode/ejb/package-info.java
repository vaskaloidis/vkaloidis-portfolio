/**
 * A package-info.java file applies package-level annotations.
 * In this case, the annotations will add elementFormDefault="qualified"
 * to all generated schemas.
 */
@XmlSchema(namespace="http://cs375.hartford.edu/geocode/1.0.1",
	elementFormDefault=XmlNsForm.QUALIFIED)
package edu.hartford.cs375.geocode.ejb;

import javax.xml.bind.annotation.XmlSchema;
import javax.xml.bind.annotation.XmlNsForm;