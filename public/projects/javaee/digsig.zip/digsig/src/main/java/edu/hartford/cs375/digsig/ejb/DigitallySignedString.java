package edu.hartford.cs375.digsig.ejb;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * This class holds a simple string and a digital signature (base64-encoded)
 * for the string.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1
 *
 */
@XmlRootElement(namespace="http://cs375.hartford.edu/digsig/1.0.1")
@XmlType(namespace="http://cs375.hartford.edu/digsig/1.0.1", propOrder={})
@XmlAccessorType(XmlAccessType.FIELD)
public class DigitallySignedString implements Serializable{

	private static final long serialVersionUID = -5744045024503168917L;

	private String text;
	private String digitalSignature;
	
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getDigitalSignature() {
		return digitalSignature;
	}
	public void setDigitalSignature(String digitalSignature) {
		this.digitalSignature = digitalSignature;
	}
	
	
}
