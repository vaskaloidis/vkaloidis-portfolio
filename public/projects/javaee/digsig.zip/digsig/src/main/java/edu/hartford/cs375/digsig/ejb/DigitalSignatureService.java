package edu.hartford.cs375.digsig.ejb;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.ejb.Singleton;

import org.apache.commons.codec.binary.Base64;

/**
 * This class is a very basic implementation of a service that generates
 * or verifies digital signatures for any given text.  For convenience,
 * the digital signatures use hard-coded public and private keys (see below),
 * which were generated from DigitalSignatureSetup.java (in src/test/java).
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 *
 */
@Singleton
public class DigitalSignatureService {
	
	//normally, the private key would be stored in a keystore, not hard-coded in java file
	private static final String privateKey = 
			"MIIBSwIBADCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2\n" + 
			"USZpRV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4\n" + 
			"O1fnxqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmC\n" + 
			"ouuEC/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCB\n" + 
			"gLRJFnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhR\n" + 
			"kImog9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoEFgIUcxvHx2PzGtQYhocOSK9IesPMChM=";
	
	//the public key could be hard-coded in java file or imported from a file.
	public static final String publicKey = 
			"MIIBtzCCASwGByqGSM44BAEwggEfAoGBAP1/U4EddRIpUt9KnC7s5Of2EbdSPO9EAMMeP4C2USZp\n" + 
			"RV1AIlH7WT2NWPq/xfW6MPbLm1Vs14E7gB00b/JmYLdrmVClpJ+f6AR7ECLCT7up1/63xhv4O1fn\n" + 
			"xqimFQ8E+4P208UewwI1VBNaFpEy9nXzrith1yrv8iIDGZ3RSAHHAhUAl2BQjxUjC8yykrmCouuE\n" + 
			"C/BYHPUCgYEA9+GghdabPd7LvKtcNrhXuXmUr7v6OuqC+VdMCz0HgmdRWVeOutRZT+ZxBxCBgLRJ\n" + 
			"FnEj6EwoFhO3zwkyjMim4TwWeotUfI0o4KOuHiuzpnWRbqN/C/ohNWLx+2J6ASQ7zKTxvqhRkImo\n" + 
			"g9/hWuWfBpKLZl6Ae1UlZAFMO/7PSSoDgYQAAoGAXjNvGf1BtybO46kEm4o+opHwwbX6zEyRlio+\n" + 
			"YXo/OvfeeF7w+LJJtPYYOEsRwY/YQtg418yGdgqFxCoXGytteseESSoV7ApJHWnmreT/FCofxFlU\n" + 
			"Wg9cuLB7eQENuEjbE2zkinB5rWfNfVuxrO+ODgIo+hCq8IN6c2wO1Jd6MYI=";

	private static PrivateKey privKey;
	private static PublicKey pubKey;
	private static Base64 base64;	

	private final static int BASE64_LINE_LENGTH = 76;
	
	static{
		init();
	}
	
	
	/**
	 * Digitally signs some text
	 * @param textToSign The text to sign
	 * @return DigitallySignedString object holding the plain text and the
	 * digital signature
	 */
	public DigitallySignedString sign(String textToSign){
		DigitallySignedString dss = new DigitallySignedString();
		try {
			Signature sig = Signature.getInstance("SHA1withDSA", "SUN"); 
			sig.initSign(privKey);
			
			try(ByteArrayInputStream bufin = new ByteArrayInputStream(textToSign.getBytes("UTF-8"))){
				byte[] buffer = new byte[1024];
				int len;
				while ((len = bufin.read(buffer)) >= 0) {
					sig.update(buffer, 0, len);
				};
			} catch(IOException e){
				throw new RuntimeException(e);
			}
						
			byte[] signature = base64.encode(sig.sign());
			dss.setText(textToSign);
			dss.setDigitalSignature(new String(signature,"UTF-8"));
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchProviderException 
				| SignatureException | UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage());
		}
		return dss;
	}
	
	
	/**
	 * Determines whether a digitally signed string is valid
	 * @param text The text that was supposedly signed
	 * @param digitalSignature The digital signature for the text
	 * @return true if the digital signature is valid; false, otherwise.
	 */
	public boolean verify(String text, String digitalSignature){
		boolean result = false;
		try {
			Signature sig = Signature.getInstance("SHA1withDSA", "SUN"); 
			sig.initVerify(pubKey);

			try(ByteArrayInputStream bufin = new ByteArrayInputStream(text.getBytes("UTF-8"))){
				byte[] buffer = new byte[1024];
				int len;
				while ((len = bufin.read(buffer)) >= 0) {
					sig.update(buffer, 0, len);
				};
			} catch(IOException e){
				throw new RuntimeException(e);
			}			
			byte[] digitalSignatureBytes = base64.decode(digitalSignature.getBytes("UTF-8"));
			result = sig.verify(digitalSignatureBytes);
		} catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidKeyException 
				| UnsupportedEncodingException e) {
			throw new RuntimeException(e.getMessage());
		} catch ( SignatureException se) {
			return false;
		}
		return result;
	}
	
	/**
	 * Initialize the keys
	 */
	private static void init(){
		base64 = new Base64(BASE64_LINE_LENGTH);
		X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(base64.decode(publicKey));
		PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(base64.decode(privateKey));
		KeyFactory keyFactory;
		try {
			keyFactory = KeyFactory.getInstance("DSA", "SUN");
			pubKey = keyFactory.generatePublic(pubKeySpec);
			privKey = keyFactory.generatePrivate(privKeySpec);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException | NoSuchProviderException e) {
			e.printStackTrace();
		}
	}
	
}
