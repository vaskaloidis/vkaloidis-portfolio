package edu.hartford.cs375.digsig.web;

import java.util.List;

import javax.ejb.EJB;
import javax.jws.WebService;

import edu.hartford.cs375.digsig.ejb.DigitalSignatureService;
import edu.hartford.cs375.digsig.ejb.DigitallySignedString;


@WebService(
		name="DigitalSignatureService",
		serviceName="DigitalSignatureService",
		targetNamespace="http://cs375.hartford.edu/digsig/1.0.1",
		endpointInterface="edu.hartford.cs375.digsig.web.DigitalSignatureWebService"
		)	
public class DigitalSignatureWebServiceImpl {
	
	@EJB
	private DigitalSignatureService ejb;
	
	public DigitallySignedString sign(String input){
		return ejb.sign(input);
	}
	
	public boolean verify(String text, String signature){
		return ejb.verify(text, signature);
	}

}
