package edu.hartford.cs375.digsig.web;


import java.util.List;

import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import edu.hartford.cs375.digsig.ejb.DigitallySignedString;

@WebService(targetNamespace="http://cs375.hartford.edu/digsig/1.0.1")
public interface DigitalSignatureWebService {
	
	@WebResult(targetNamespace="http://cs375.hartford.edu/digsig/1.0.1")
	public DigitallySignedString sign(String textToSign);
	
	@WebResult(targetNamespace="http://cs375.hartford.edu/digsig/1.0.1")
	public boolean verify(String text, String digitalSignature);
	
}

