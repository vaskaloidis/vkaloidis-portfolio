package edu.hartford.cs375.digsig.web;

import static org.junit.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Logger;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import edu.hartford.cs375.digsig.web.DigitalSignatureWebService;
import edu.hartford.cs375.digsig.ejb.DigitalSignatureService;
import edu.hartford.cs375.digsig.ejb.DigitallySignedString;

/**
 * This class tests the DigitalSignatureWebService.  Note that the sign() method cannot
 * be easily tested, as it generates a new digital signature each time it is called.  The
 * verify() method can be tested; however.  Before each test, a new signature is generated,
 * and then the verify() method is tested.  In one test, the verify() method should pass.  In
 * the other two tests, the verify() method should fail.
 * 
 * @author dennis
 *
 */
public class DigitalSignatureWebServiceIT {

	private final static Logger logger = Logger.getLogger(DigitalSignatureWebServiceIT.class.getSimpleName());

	private static DigitalSignatureWebService dsService;
	
	private final static String testMessage = "This is a plain text message, which requires a digital signature.";
	private static String testDigitalSignature;
	
	@BeforeClass
	public static void setupClass() throws MalformedURLException{
		URL wsdlURL = new URL("http://localhost:8080/digsig/DigitalSignatureService?wsdl");
		QName serviceName = new QName("http://cs375.hartford.edu/digsig/1.0.1", "DigitalSignatureService");

		Service service = Service.create(wsdlURL,serviceName);
		dsService = service.getPort(DigitalSignatureWebService.class);
	}
	

	/**
	 * Generate a new digital signature before each test.
	 */
	@Before
	public void getDigitalSignature(){
		DigitallySignedString dss = dsService.sign(testMessage);
		testDigitalSignature = dss.getDigitalSignature();
		logger.info("getDigitalSignature() ... digitalSignature:\n" + testDigitalSignature);
	}
	
	/**
	 * Tests that the verify method succeeds when the digital signature is valid
	 * for the message and the message has not been altered.
	 */
	@Test
	public void testVerifyGood() {
		boolean isValid = dsService.verify(testMessage,testDigitalSignature);
		logger.info("testSignAndVerifyGood() ... should be true:\n" + isValid);
		assertEquals(true,isValid);
	}

	/**
	 * Tests that the verify method fails when the digital signature is valid
	 * but the message has been altered/tampered with.
	 */
	@Test
	public void testVerifyBadMessageAltered() {
		boolean isValid = dsService.verify(testMessage + "!",testDigitalSignature);
		logger.info("testVerifyBadMessageAltered() ... should be false:\n" + isValid);
		assertEquals(false,isValid);
	}
	
	/**
	 * Tests that the verify method fails when the digital signature is not valid
	 * for the message.
	 */
	@Test
	public void testVerifyBadSignature() {
		boolean isValid = dsService.verify(testMessage,"FdA2E1ipZ3U45j/o0eYGECGQD3qdN7dnvMPLRjSNBiRM6Z4PLQUgpzFJfMDYCGQDITe4tkGNAoq=");
		logger.info("testVerifyBadSignature() ... should be false:\n" + isValid);
		assertEquals(false,isValid);
	}
	
}

