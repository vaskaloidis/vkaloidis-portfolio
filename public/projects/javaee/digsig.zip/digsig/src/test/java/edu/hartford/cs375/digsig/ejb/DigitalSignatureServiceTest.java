package edu.hartford.cs375.digsig.ejb;

import static org.junit.Assert.assertEquals;
import java.util.logging.Logger;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


/**
 * This class tests the DigitalSignatureService EJB class (as a Java SE test).
 * Note that the sign() method is not tested, only the verify() method.  The sign()
 * method is called before each verify() test in order to generate a new digital
 * signature.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 *
 */
public class DigitalSignatureServiceTest {
	
	private final static Logger logger = Logger.getLogger(DigitalSignatureServiceTest.class.getSimpleName());
	

	private static DigitalSignatureService dsService;
	
	private final static String testMessage = "This is a plain text message, which requires a digital signature.";
	private static String testDigitalSignature;
	
	
	/**
	 * Setup the test class by creating a reference to a DigitalSignatureService object.
	 */
	@BeforeClass
	public static void setupClass() {
		dsService = new DigitalSignatureService();
	}
	

	/**
	 * Generate a new digital signature before each test.
	 */
	@Before
	public void getDigitalSignature(){
		DigitallySignedString dss = dsService.sign(testMessage);
		testDigitalSignature = dss.getDigitalSignature();
		logger.info("getDigitalSignature() ... digitalSignature:\n" + testDigitalSignature);
	}
	
	/**
	 * Tests that the verify method succeeds when the digital signature is valid
	 * for the message and the message has not been altered.
	 */
	@Test
	public void testVerifyGood() {
		boolean isValid = dsService.verify(testMessage,testDigitalSignature);
		logger.info("testSignAndVerifyGood() ... should be true:\n" + isValid);
		assertEquals(true,isValid);
	}

	/**
	 * Tests that the verify method fails when the digital signature is valid
	 * but the message has been altered/tampered with.
	 */
	@Test
	public void testVerifyBadMessageAltered() {
		boolean isValid = dsService.verify(testMessage + "!",testDigitalSignature);
		logger.info("testVerifyBadMessageAltered() ... should be false:\n" + isValid);
		assertEquals(false,isValid);
	}
	
	/**
	 * Tests that the verify method fails when the digital signature is not valid
	 * for the message.
	 */
	@Test
	public void testVerifyBadSignature() {
		boolean isValid = dsService.verify(testMessage,"FdA2E1ipZ3U45j/o0eYGECGQD3qdN7dnvMPLRjSNBiRM6Z4PLQUgpzFJfMDYCGQDITe4tkGNAoq=");
		logger.info("testVerifyBadSignature() ... should be false:\n" + isValid);
		assertEquals(false,isValid);
	}
	
}
