package edu.hartford.cs375.digsig.ejb;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;

import org.apache.commons.codec.binary.Base64;


/**
 * NOTE: for the final exam, you don't have to worry about this class,
 * as the digital signature keys have already been generated for you.
 * 
 * This class generates public and private keys for use in
 * digital signatures.  The generated keys can be copied and pasted
 * into the DigitalSignatureService to utilize a different keyset.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 */
public class DigitalSignatureSetup {

	private final static int BASE64_LINE_LENGTH = 76;

	
	  public static void main(String[] args)
			    throws NoSuchAlgorithmException, NoSuchProviderException, 
			    InvalidAlgorithmParameterException, UnsupportedEncodingException {
		  
	        /* Generate a DSA signature */
        	KeyPairGenerator keyGen = KeyPairGenerator.getInstance("DSA","SUN");
        	SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
        	random.setSeed(new java.util.Date().getTime());

        	keyGen.initialize(1024, random);
        	KeyPair pair = keyGen.generateKeyPair();

        	byte[] privateKeyBytes = new Base64(BASE64_LINE_LENGTH).encode(pair.getPrivate().getEncoded());
    	    byte[] publicKeyBytes = new Base64(BASE64_LINE_LENGTH).encode(pair.getPublic().getEncoded());
    	    
    	    //send to console
    	    System.out.println("Private Key:\n" + new String(privateKeyBytes,"UTF-8") );
    	    System.out.println("Public Key:\n" + new String(publicKeyBytes,"UTF-8") );	
        	        	
	    
	}
	
}
