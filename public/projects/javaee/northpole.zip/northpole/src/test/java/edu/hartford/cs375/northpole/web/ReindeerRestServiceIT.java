package edu.hartford.cs375.northpole.web;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.edennis.util.FileToString;
import com.edennis.xml.XmlNormalizer;
import com.edennis.xml.XmlTester;
import com.jayway.restassured.RestAssured;

import static com.jayway.restassured.RestAssured.*;
import static org.junit.Assert.assertEquals;

/**
 * This integration test class tests methods in the 
 * ReindeerRestService class.
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 *
 */
public class ReindeerRestServiceIT {

	private final static Logger logger = Logger.getLogger("ReindeerRestServiceIT");

	/**
	 * Sets up this test class by setting the base URL for the
	 * REST service.
	 */
	@BeforeClass
	public static void setupClass(){
		
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = 8080;
		RestAssured.basePath = "/northpole"; //note this is the name of your artifactId/project
		
	}

	/**
	 * Sets up each Test method by resetting the database via
	 * the DatabaseResetterServlet
	 */
	@Before
	public void setupMethod(){
		logger.info(given().when().post("/reset").getBody().asString());
	}
		
	
	/**
	 * Tests that a GET on the relative URL "/reindeer" returns
	 * XML equivalent to that found in the file "reindeer-getall.xml"
	 * in src/test/resources.
	 */
	@Test
	public void testDoGetAll(){
				String actualXml = 
					given() 
					.header("Accept","application/xml")
					.when()  
					.get("/reindeer")
					.getBody()
					.asString();
			
		String expectedXml = FileToString.getFileAsString("reindeer-getall.xml");		
		logger.info("testDoGetAll()\n" + XmlNormalizer.prettyPrint(actualXml));		
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	}
	

	/**
	 * Tests that a GET on the relative URL "/reindeer/5" returns
	 * XML equivalent to that found in the file "reindeer-get5.xml"
	 * in src/test/resources.
	 */
	@Test
	public void testDoGet5(){
		String actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.get("/reindeer/5") 
				.getBody() 
				.asString(); 
			
		String expectedXml = FileToString.getFileAsString("reindeer-get5.xml");
		logger.info("testDoGet5()\n" + XmlNormalizer.prettyPrint(actualXml));	
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	}


	/**
	 * Tests the following:
	 * <ol>
	 *   <li>a POST on the relative URL "/reindeer" using XML from
	 * the file "reindeer-post-input.xml" as the request message body.
	 * The response message should be XML that is equivalent
	 * to that found in the file "reindeer-post-output.xml"
	 * in src/test/resources.
	 *   </li>
	 *   <li>a subsequent GET on the relative URL "/reindeer", without
	 * resetting the database.  The response message should be
	 * XML that is equivalent to that found in the file 
	 * "reindeer-post-then-getall.xml" in src/test/resources.
	 *   </li>
	 * </ol>
	 */
	@Test
	public void testDoPost(){
		String inputXml = FileToString.getFileAsString("reindeer-post-input.xml");
		String actualXml = 
			given() 
				.header("Accept","application/xml")
				.contentType("application/xml")
				.body(inputXml)
				.when()
				.post("/reindeer")
				.getBody()
				.asString();
			
		//CHECK CREATED RECORD (SHOULD HAVE CORRECT ID)
		String expectedXml = FileToString.getFileAsString("reindeer-post-output.xml");
		logger.info("testDoPost() ... created rec \n" + XmlNormalizer.prettyPrint(actualXml));	
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
		
		//NOW DO GET ALL (SHOULD INCLUDE CREATED RECORD)
		actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.get("/reindeer")
				.getBody()
				.asString();
		
			
		expectedXml = FileToString.getFileAsString("reindeer-post-then-getall.xml");
		logger.info("testDoPost() ... all recs\n" + XmlNormalizer.prettyPrint(actualXml));		
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);				
		
	}
	
	/**
	 * Tests the following:
	 * <ol>
	 *   <li>a PUT on the relative URL "/reindeer" using XML from
	 * the file "reindeer-put7.xml" as the request message body.
	 * The response message should be XML that is equivalent
	 * to that found in the file "reindeer-put7.xml"
	 * in src/test/resources.
	 *   </li>
	 *   <li>a subsequent GET on the relative URL "/reindeer", without
	 * resetting the database.  The response message should be
	 * XML that is equivalent to that found in the file 
	 * "reindeer-put7-then-getall.xml" in src/test/resources.
	 *   </li>
	 * </ol>
	 */
	@Test
	public void testDoPut7(){
		String inputXml = FileToString.getFileAsString("reindeer-put7.xml");
		String actualXml = 
				given() 
					.header("Accept","application/xml")
					.contentType("application/xml")
					.body(inputXml)
					.when()
					.put("/reindeer")
					.getBody()
					.asString();

		
		//CHECK UPDATED RECORD (SHOULD HAVE CORRECT PERCENT COMPLETE)
		String expectedXml = FileToString.getFileAsString("reindeer-put7.xml");
		logger.info("testDoPut7()\n" + XmlNormalizer.prettyPrint(actualXml));			
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	
		//NOW DO GET ALL (SHOULD HAVE CORRECTED RECORD)
		actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.get("/reindeer")
				.getBody()
				.asString();

			
		expectedXml = FileToString.getFileAsString("reindeer-put7-then-getall.xml");
		logger.info("testDoPut7() ... all recs\n" + XmlNormalizer.prettyPrint(actualXml));		
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);				

	}

	
	/**
	 * Tests the following:
	 * <ol>
	 *   <li>a DELETE on the relative URL "/reindeer/4".
	 * The response status code should equal 204 (NO CONTENT).
	 * ***If the delete method in ReindeerRestService is coded to
	 * return a text message, then this test method will need
	 * to be altered to accept a 200 status code and/or to test
	 * the response message.
	 *   </li>
	 *   <li>a subsequent GET on the relative URL "/reindeer", without
	 * resetting the database.  The response message should be
	 * XML that is equivalent to that found in the file 
	 * "reindeer-delete4-then-getall.xml" in src/test/resources.
	 *   </li>
	 * </ol>
	 */
	@Test
	public void testDoDelete4(){
		int status = 
				given() 
				.header("Accept","text/plain") 
				.when()
				.delete("/reindeer/4")
				.getStatusCode();
		
		//CHECK DELETE (SHOULD RETURN 204 - NO CONTENT STATUS)
		logger.info("testDoDelete4() ... status \n" + Integer.valueOf(status));		
		assertEquals(204,status);
		
		
		//NOW DO GET ALL (SHOULD NOT HAVE DELETED RECORD)
		String actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.get("/reindeer")
				.getBody()
				.asString();

			
		String expectedXml = FileToString.getFileAsString("reindeer-delete4-then-getall.xml");
		logger.info("testDoDelete4() ... all remaining recs\n" + XmlNormalizer.prettyPrint(actualXml));		
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	}
	

	/**
	 * Tests a GET on the relative URL "/reindeer/param" with a query
	 * parameter of ?id=5.  This GET should return XML
	 * equivalent to that found in the file "reindeer-get5.xml"
	 * in src/test/resources.
	 */
	@Test
	public void testDoGet5Param(){
		String actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.param("id", 5) 
				.get("/reindeer/param") 
				.getBody() 
				.asString(); 
		
		String expectedXml = FileToString.getFileAsString("reindeer-get5.xml");
		logger.info("testDoGet5Param()\n" + XmlNormalizer.prettyPrint(actualXml));	
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	}

	
	/**
	 * Tests the following:
	 * <ol>
	 *   <li>a POST on the relative URL "/reindeer/param" using form
	 * parameters for input. The response message should be XML 
	 * that is equivalent to that found in the file 
	 * "reindeer-post-output.xml" in src/test/resources.
	 *   </li>
	 *   <li>a subsequent GET on the relative URL "/reindeer/param", without
	 * resetting the database.  The response message should be
	 * XML that is equivalent to that found in the file 
	 * "reindeer-post-then-getall.xml" in src/test/resources.
	 *   </li>
	 * </ol>
	 */
	@Test
	public void testDoPostParam(){
		String actualXml = 
				given()
				.header("Accept","application/xml") 
				.when()
				.param("name", "Rudolph the red nosed raindeer")
				.post("/reindeer/param")
				.getBody()
				.asString();
			
		//CHECK CREATED RECORD (SHOULD HAVE CORRECT ID)
		String expectedXml = FileToString.getFileAsString("reindeer-post-output.xml");
		logger.info("testDoPostParam() ... created rec \n" + XmlNormalizer.prettyPrint(actualXml));	
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
		
		//NOW DO GET ALL (SHOULD INCLUDE CREATED RECORD)
		actualXml = 
				given() 
				.header("Accept","application/xml") 
				.when()
				.get("/reindeer")
				.getBody()
				.asString();
		
			
		expectedXml = FileToString.getFileAsString("reindeer-post-then-getall.xml");
		logger.info("testDoPostParam() ... all recs\n" + XmlNormalizer.prettyPrint(actualXml));		
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);				
		
	}


	/**
	 * Tests that a POST at the relative URL "/reindeer/param" with
	 * the provided form parameters, where lastModified is a bad
	 * date, returns a custom error message (presumably created
	 * with a WebApplicationException).  The content of the 
	 * custom error message must be equivalent to that found in
	 * the file "reindeer-last-modified-parse-error.xml" in
	 * src/test/resources.
	 */
	@Test
	public void testDoPostParamDuplicateReindeer(){
		String actualXml = 
				given()
				.header("Accept","application/xml") 
				.when()
				.param("name", "Timmy the blue nosed reindeer")
				.post("/reindeer/param")
				.getBody()
				.asString();
			
		//CHECK CREATED RECORD (SHOULD HAVE CORRECT ID)
		String expectedXml = FileToString.getFileAsString("duplicate-reindeer-error.xml");
		logger.info("testDoPostParamDuplicateReindeer ... error message: \n" + XmlNormalizer.prettyPrint(actualXml));	
		XmlTester.assertEqualsIgnoreFormatAndOrder(expectedXml, actualXml);		
		
	}
	
	
}
