package edu.hartford.cs375.northpole.ejb;

import static org.junit.Assert.assertEquals;

import java.util.logging.Logger;

import org.junit.Before;
import org.junit.Test;

/**
 * DON'T PAY ANY ATTENTION TO THIS CODE.  IT IS JUST FOR FUN.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 *
 */
public class ReindeerDataServiceTest {
	
	private final static Logger logger = Logger.getLogger("ReindeerDataServiceTest");

	static ReindeerDataService ds = new ReindeerDataService();
	
	@Before
	public void setupTest(){
		ds.reset();
	}
	
	@Test
	public void testSanta(){
		logger.info(ds.santa());
		assertEquals("Now, Dasher! Now, Dancer! Now, Prancer and Vixen! On, Comet! On, Cupid! On, Donner and Blitzen!",ds.santa());
	}
	@Test
	public void testDelete8ThenSanta(){	
		ds.delete(8);
		logger.info(ds.santa());
		assertEquals("Now, Dasher! Now, Dancer! Now, Prancer and Vixen! On, Comet! On, Cupid! On, Donner!",ds.santa());
	}
	@Test
	public void testCreateThenSanta(){	
		ds.create(new Reindeer("Rudolph"));
		logger.info(ds.santa());
		assertEquals("Now, Dasher! Now, Dancer! Now, Prancer and Vixen! On, Comet! On, Cupid! On, Donner and Blitzen! Giddyup, Rudolph!",ds.santa());
	}
	@Test
	public void testUpdate7ThenSanta(){	
		ds.update(new Reindeer(7,"Donder"));
		logger.info(ds.santa());
		assertEquals("Now, Dasher! Now, Dancer! Now, Prancer and Vixen! On, Comet! On, Cupid! On, Donder and Blitzen!",ds.santa());
	}
	
	@Test(expected=DuplicateReindeerException.class)
	public void testDuplicateReindeerOnCreate(){
		ds.create(new Reindeer("Dasher"));
	}
	
	@Test(expected=DuplicateReindeerException.class)
	public void testDuplicateReindeerOnUpdate(){
		ds.update(new Reindeer(2,"Dasher"));
	}
}
