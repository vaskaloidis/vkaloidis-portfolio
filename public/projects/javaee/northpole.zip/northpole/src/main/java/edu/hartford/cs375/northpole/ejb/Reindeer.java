package edu.hartford.cs375.northpole.ejb;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * This model class holds data for a reindeer.
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 *
 */
@XmlRootElement
public class Reindeer implements Serializable {

	private static final long serialVersionUID = -4291641495382102565L;
	
	private int id;
	private String name;
		
	/**
	 * Constructs a new reindeer object with the given name.
	 * Note that this constructor is useful for create/post
	 * operations.
	 * @param name The name of the new reindeer
	 */
	public Reindeer(String name) {
		this.name = name;
	}
	
	/**
	 * Constructs a new reindeer object with the given name.
	 * Note that this constructor is useful for update/put
	 * operations.
	 * @param id The id of the reindeer.
	 * @param name The name of the reindeer.
	 */
	public Reindeer(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	/**
	 * Constructs a new reindeer without an id or name.
	 */
	public Reindeer() {
		super();
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	
}
