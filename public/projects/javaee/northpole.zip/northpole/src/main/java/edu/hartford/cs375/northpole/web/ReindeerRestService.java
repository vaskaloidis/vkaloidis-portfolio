package edu.hartford.cs375.northpole.web;

import java.util.List;

import javax.ejb.EJB;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import edu.hartford.cs375.northpole.ejb.DuplicateReindeerException;
import edu.hartford.cs375.northpole.ejb.Reindeer;
import edu.hartford.cs375.northpole.ejb.ReindeerDataService;


@Path("reindeer")
public class ReindeerRestService {
	
	//TODO: add EJB injection for ReindeerDataService
	@EJB
	ReindeerDataService ejb;

	//TODO: add method to get all reindeer
	@GET
	@Produces("application/xml")
	public List<Reindeer> getAllReindeer(){
		return ejb.getAll();
	}
	
	//TODO: add method to get one reindeer by id, using a path parameter for id
	@GET
	@Path("{id}")
	@Produces("application/xml")
	public Reindeer getReindeer(@PathParam("id") int id){
		return ejb.get(id);
	}
	
	//TODO: add method to post a new reindeer record, submitted to service as XML	
	@POST
	@Consumes("application/xml")
	@Produces("application/xml")
	public Reindeer createReindeer(Reindeer reindeer){
		return ejb.create(reindeer);
	}
	
	//TODO: add method to put a modified reindeer record, submitted to service as XML
	@PUT
	@Consumes("appliation/xml")
	@Produces("application/xml")
	public Reindeer updateReindeer(Reindeer reindeer){
		return ejb.update(reindeer);
	}
	
	
	//TODO: add method to delete a reindeer by id, using a path parameter for id
	//		*** NOTE: If you decide to return a value after delete (e.g., 
	//		text message), you will have to update ReindeerRestServiceIT to
	//		expect a 200 status; when no message is returned from delete, 
	//		the expected status is 204.  At present,  ReindeerRestServiceIT 
	//		expects no return message and hence a 204 status.
	@DELETE
	@Path("{id}")
	@Produces("text/plain")
	public void deleteReindeer(@PathParam("id") int id){
		ejb.delete(id);
	}
	
	
	//TODO: add method to get one reindeer by id, using a query parameter for the id.
	//		Include a path component "param" to ensure that the URL for this version
	//		of the GET method is unique
	@GET
	@Path("{id}")
	@Produces("text/plain")
	public Reindeer getAReindeer(@QueryParam("id") int id){
		
		return ejb.get(id);
		
	}
	
	//TODO: add method to post a new reindeer record, submitted as the following 
	//		form parameters: name (String);
	//		*** Include a path component "param" to ensure that the URL for this
	//		version of the POST method is unique
	//		***Add a try-catch block for a DuplicateReindeerException, which
	//      throws a WebApplicationException.  Feel free to use the 
	//      buildDuplicateReindeerExceptionXml(String name) method below to
	//      build the .entity part of the response.  The XML response should look
	//      similar to that should in "src/test/java/duplicate-reindeer-error.xml"

	@POST
	@Path("param")
	@Consumes("application/x-www-forum-urlencoded")
	@Produces("application/xml")
	public Reindeer createReindeer(
			@FormParam("name") String name){
		
		try{
			
			return ejb.create(new Reindeer(name));
			
		} catch(DuplicateReindeerException e) {
			
			String xml = buildDuplicateReindeerExceptionXml(name);
			
			throw new WebApplicationException(Response
					.status(Status.BAD_REQUEST)
					.entity(xml)
					.build());
		}
		
	}


	/**
	 * Builds the XML portion of the response for a DuplicateReindeerException
	 * Note: Adapted from code from your classmate, Rob.  Thanks, Rob.
	 * The code uses dom4j, the dependency for which was added to your Maven
	 * POM file already.
	 * @param name The name of the reindeer
	 */
	private String buildDuplicateReindeerExceptionXml(String name){
		Document doc = DocumentHelper.createDocument();
		
		Element error = doc.addElement("error");
		error.addElement("description")
				.addText("A reindeer with this name already exists in Santa's team.  Please choose another name.");
		error.addElement("reindeerName")
				.addText(name);
		
		return doc.asXML();
	}
	
	
}
