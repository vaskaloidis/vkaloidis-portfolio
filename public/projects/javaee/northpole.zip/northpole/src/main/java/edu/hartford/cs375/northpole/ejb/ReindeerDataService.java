package edu.hartford.cs375.northpole.ejb;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Singleton;

import com.edennis.util.FileToString;
import com.edennis.xmljson.JaxbSerializer;
import com.edennis.xmljson.MediaType;

/**
 * This Enterprise Java Bean (EJB) class provides methods for creating, reading, updating,
 * and deleting reindeer in an in-memory data structure.  For convenience, the class
 * also exposes a reset method, which resets the collection of reindeer to those 
 * contained in the reindeer-getall.xml file.
 * 
 * There is an extra method called santa(), which I used for some EJB testing.
 * Please ignore for this assignment.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1, 12/215/2013
 *
 */
@Singleton
public class ReindeerDataService {
	
	//in-memory data structure for holding reindeer.  This is used
	//in lieu of a database (for convenience in this project).
	private Map<Integer,Reindeer> reindeerMap = new LinkedHashMap<Integer,Reindeer>();
	
	//the unique ID for the reindeer.
	private int nextId = 1;
	
	//the starting data
	public static String REINDEER_DATA_FILE = "reindeer-getall.xml";
	
	/**
	 * Gets the reindeer with the provided ID
	 * @param id The unique numeric ID of the reindeer
	 * @return The reindeer associated with the provided ID
	 */
	public Reindeer get(Integer id){
		return reindeerMap.get(id);
	}	
	
	/**
	 * Gets all of the reindeer currently held by this data service EJB.
	 * @return All reindeer currently in the data service
	 */
	public List<Reindeer> getAll(){
		List<Reindeer> reindeerList = new ArrayList<Reindeer>();
		for(Reindeer reindeer : reindeerMap.values())
			reindeerList.add(reindeer);
		return reindeerList;
	}

	/**
	 * Creates a new Reindeer object with the name from the provided
	 * Reindeer parameter
	 * @param reindeer A reindeer object whose name will be used
	 * to create a new reindeer in the data service.
	 * @return The newly created reindeer
	 * @throws DuplicateReindeerException If the name already exists.
	 * Note that because DuplicateReindeerException extends 
	 * RuntimeException (rather than Exception), handing of the exception
	 * optional. (Although you are asked to handle it in one of your
	 * REST service methods)
	 * @see DuplicateReindeerException
	 */
	public Reindeer create(Reindeer reindeer) throws DuplicateReindeerException{		
		//check that the reindeer's new name isn't
		//the same as an existing reindeer's name.
		//That would be confusing to Santa.
		for(Reindeer r : reindeerMap.values())
			if(reindeer.getName().equalsIgnoreCase(r.getName()))
					throw new DuplicateReindeerException();		
		
		reindeer.setId(nextId);
		reindeerMap.put(nextId,reindeer);
		nextId++;
		return reindeer;
	}
	
	/**
	 * Updates an existing Reindeer object with the name from the provided
	 * Reindeer parameter
	 * @param reindeer A reindeer object whose name will be used
	 * to update an existing reindeer in the data service.
	 * @return The newly updated reindeer
	 * @throws DuplicateReindeerException If the name already exists for
	 * another reindeer.
	 * Note that because DuplicateReindeerException extends 
	 * RuntimeException (rather than Exception), handing of the exception
	 * optional. (Although you are asked to handle it in one of your
	 * REST service methods)
	 * @see DuplicateReindeerException
	 */
	public Reindeer update(Reindeer reindeer) throws DuplicateReindeerException{	
		//check that the reindeer's new name isn't
		//the same as an existing reindeer's name.
		//That would be confusing to Santa.
		for(Reindeer r : reindeerMap.values()){
			if(reindeer.getName().equalsIgnoreCase(r.getName())
					&& reindeer.getId() != r.getId())
					throw new DuplicateReindeerException();		
		}		
		reindeerMap.put(reindeer.getId(),reindeer);
		return reindeer;
	}
	
	/**
	 * Deletes an existing reindeer
	 * @param id The ID of the reindeer to delete
	 */
	public void delete(int id){
		reindeerMap.remove(id);
	}	

	
	/**
	 * Repopulates the collection of reindeer from an XML file 
	 * (in src/main/resources).
	 * @see REINDEER_DATA_FILE
	 */
	public void reset(){
		reindeerMap.clear();
		nextId = 1;
		String xml = FileToString.getFileAsString(REINDEER_DATA_FILE);
		List<Reindeer> reindeers = JaxbSerializer.deserializeList(xml, Reindeer.class, MediaType.APPLICATION_XML);
		for(Reindeer reindeer : reindeers){
			create(reindeer);
		}		
	}
	
	/**
	 * Returns Santa's famous call to his reindeer (with some 
	 * variation for additional reindeer or no reindeer).
	 * 
	 * @return String representing Santa's call
	 */
	public String santa(){
		StringBuffer sb = new StringBuffer();
		List<Reindeer> reindeerList = getAll();
		
		if(reindeerList.size()==0)
			return "Ho! Ho! Ho!  Where are my reindeer?";
		
		String[] call = {"Now","On","Giddyup"};
		
		//yes, Santa appreciates a good algorithm!
		for(int i=0;i<reindeerList.size();i++){
			if((i+1) % 4 == 0)
				sb.append(" and ");
			else
				sb.append(call[(int)(i%12)/4] + ", ");
					
			sb.append(reindeerList.get(i).getName());
			
			if((i+1) % 4 != 3 || i == reindeerList.size() - 1)
				sb.append("! ");			
			
		}
		return sb.toString().trim();
	}

	
}
