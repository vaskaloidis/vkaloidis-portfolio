package edu.hartford.cs375.northpole.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.hartford.cs375.northpole.ejb.ReindeerDataService;

/**
 * This servlet class provides a means of resetting a database through 
 * a simple HTTP POST to "http://localhost:8080/northpole/reset".  This kind
 * of servlet should never be included in a production deployment, but
 * it can be useful for running informal tests with a testing tool 
 * such as Postman.
 * @author Dennis Mitchell
 * @version 1.0.1, 10/06/2013
 */
@WebServlet("/reset")
public class DatabaseResetterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	ReindeerDataService ejb;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DatabaseResetterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ejb.reset();
		PrintWriter out = response.getWriter();
		response.addHeader("Content-Type", "text/plain");
		out.print("Database has been reset.");
	}

}
