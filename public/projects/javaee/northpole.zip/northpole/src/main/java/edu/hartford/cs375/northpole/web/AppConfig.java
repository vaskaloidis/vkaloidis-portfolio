package edu.hartford.cs375.northpole.web;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Application class for REST service.  To keep the URL
 * for the service simple, you can specify an empty
 * string in the ApplicationPath annotation
 * @author Dennis Mitchell
 * @version 1.0.1
 */
@ApplicationPath("")
public class AppConfig extends Application
{
}
