package edu.hartford.cs375.northpole.ejb;

import javax.ejb.ApplicationException;

/**
 * Ordinarily an exception thrown in an EJB will be wrapped by an EJBException object.
 * To prevent this EJBException wrapper, you can create your own exception class
 * that is annotated with ApplicationException.  This annotation also
 * accepts a rollback attribute, which can be set to true if you want to rollback
 * any transactions (e.g., database updates) that were started when the exception
 * was thrown.
 * 
 * Note: if you want to FORCE clients of this EJB to handle the exception, then
 * extend Exception, rather than RuntimeException.  RuntimeException makes the
 * exception handling code OPTIONAL.
 * 
 * @author Dennis Mitchell
 * @version 1.0.1, 12/15/2013
 */
@ApplicationException(rollback=true)
public class DuplicateReindeerException extends RuntimeException {

	private static final long serialVersionUID = 2287772617119577620L;
	
	public String getMessage(){
		return "A reindeer with this name already exists in Santa's team.  Please choose another name.";
	}
}
